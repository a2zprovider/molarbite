<template>
  <div class="p-9">
    <div
      class="relative overflow-x-auto border-[2px] border-[#0052CC] rounded-xl"
    >
      <table
        class="w-full border-collapse border-spacing-[25px] text-base font-medium leading-6 rounded-xl text-left"
      >
        <thead class="bg-[#0052CC]">
          <tr>
            <th
              scope="col"
              colSpan="3"
              class="px-6 py-3 font-medium text-lg lending-5 text-white"
            >
              Patient Details
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>First Name</p>
                <p class="text-[#0052CC]">Mr. Doctor Dental</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Middle Name</p>
                <p class="text-[#0052CC]">Mr. Doctor Dental</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Last Name</p>
                <p class="text-[#0052CC]">Mr. Doctor Dental</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Email</p>
                <p class="text-[#0052CC]">doctor@molarbyte.com</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Mobile Number</p>
                <p class="text-[#0052CC]">+91 99999 99999</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Alt Mobile Number</p>
                <p class="text-[#0052CC]">+91 99999 99999</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Gender</p>
                <p class="text-[#0052CC]">Male</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Preferred Language</p>
                <p class="text-[#0052CC]">English</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Date of Birth</p>
                <p class="text-[#0052CC]">01-01-1990</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Pincode</p>
                <p class="text-[#0052CC]">560098</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Employer</p>
                <p class="text-[#0052CC]">Employer</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Occupation</p>
                <p class="text-[#0052CC]">Occupation</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>Preferred Mode of Communication</p>
                <div></div>
              </div>
            </td>
          </tr>
        </tbody>
        <thead class="bg-[#0052CC]">
          <tr>
            <th
              scope="col"
              colSpan="3"
              class="px-6 py-3 font-medium text-lg lending-5 text-white"
            >
              Family Member
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Name</p>
                <p class="text-[#0052CC]">Mr. Doctor Dental</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Relationship</p>
                <p class="text-[#0052CC]">Brother</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Mobile Number</p>
                <p class="text-[#0052CC]">+91 99999 99999</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Email</p>
                <p class="text-[#0052CC]">doctor@molarbyte.com</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Seen by us?</p>
                <p class="text-[#0052CC]">Yes</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Referred by?</p>
                <p class="text-[#0052CC]">Mr. Raju Kumar</p>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>How did you get to know about us?</p>
                <div></div>
              </div>
            </td>
          </tr>
        </tbody>
        <thead class="bg-[#0052CC]">
          <tr>
            <th
              scope="col"
              colSpan="3"
              class="px-6 py-3 font-medium text-lg lending-5 text-white"
            >
              Dental History
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>When was your last dental visit?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>Did you experience any of the following?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>Rate your dental fear</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>What is the reason for today’s visit?</p>
                <div></div>
              </div>
            </td>
          </tr>
        </tbody>
        <thead class="bg-[#0052CC]">
          <tr>
            <th
              scope="col"
              colSpan="3"
              class="px-6 py-3 font-medium text-lg lending-5 text-white"
            >
              Emergency Contact Number
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white border-b border-[#0052CC]">
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Name</p>
                <p class="text-[#0052CC]">Mr. Doctor Dental</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4 border-r border-[#0052CC]">
              <div class="flex justify-between items-center">
                <p>Relationship</p>
                <p class="text-[#0052CC]">Brother</p>
              </div>
            </td>
            <td scope="row" class="px-6 py-4">
              <div class="flex justify-between items-center">
                <p>Mobile Number</p>
                <p class="text-[#0052CC]">+91 99999 99999</p>
              </div>
            </td>
          </tr>
        </tbody>
        <thead class="bg-[#0052CC]">
          <tr>
            <th
              scope="col"
              colSpan="3"
              class="px-6 py-3 font-medium text-lg lending-5 text-white"
            >
              Medical History
            </th>
          </tr>
        </thead>
        <tbody>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>What is your current health like?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>What are your current medical conditions?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>List of Current Medication</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>What allergies do you have?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>Do you smoke or consume alcohol?</p>
                <div></div>
              </div>
            </td>
          </tr>
          <tr class="bg-white border-b border-[#0052CC]">
            <td
              scope="row"
              colSpan="3"
              class="px-6 py-4 border-r border-[#0052CC]"
            >
              <div class="flex justify-between items-center">
                <p>Are you pregnant?</p>
                <div></div>
              </div>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="flex justify-center items-center gap-10 mt-4">
      <ReusablesBaseButton
        @click="$router.push('/dashboard/doctor/patient/details')"
        label="Go Back"
        iconClass="text-white"
        icon-left="arrow-left"
        :left-size="12"
        className="flex justify-center items-center rounded bg-[#3366FF] px-4 py-2 text-xs font-medium leading-4 text-white"
      />
      <ReusablesBaseButton
        label="Print"
        iconClass="text-[#696F8C]"
        icon-left="printer"
        :left-size="12"
        className="flex justify-center items-center rounded bg-white px-4 py-2 text-xs font-medium leading-4 text-[#696F8C] border-[1px] border-[#828282]"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
definePageMeta({ layout: "owner" });

import useVuelidate from "@vuelidate/core";
import { required, email, minLength, maxLength } from "@vuelidate/validators";

const closeModal = () => {
  state.isVisible = !state.isVisible;
};

// Form inputs
const state = reactive<{
  isVisible: boolean;
}>({
  isVisible: false,
});
</script>

<style scoped></style>