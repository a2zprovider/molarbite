<template>
    <div
      class="h-screen flex justify-center items-center flex-col gap-y-1 container text-center"
    >
      <h1 class="text-9xl lg:text-[200px] font-bold">
        4<span class="text-[#EF4444] animate-pulse">0</span>4
      </h1>
      <p class="font-semibold text-2xl">Looks like you're lost</p>
      <p class="font-light text-sm">We can't seem to find the page you're looking for</p>
      <RouterLink to="/" class="btn mt-12 rounded-full"
        >Go Back Home <Icon name="mdi:arrow-right"
      /></RouterLink>
    </div>
  </template>
  
  <script setup lang="ts"></script>
  
  <style scoped></style>